Task 9 archive probe without ResourceEx.json.
